# Execute com Blender: blender -b --python criar_demo_blender.py -- Deformacao_Demo.blend
import bpy,sys
bpy.ops.wm.read_factory_settings(use_empty=True)
for name,z in [('Base Cambio',0),('Cabeca Cambio',2)]:
 bpy.ops.mesh.primitive_cube_add(size=.1,location=(0,0,z));bpy.context.object.name=name
m=bpy.data.meshes.new('coifa');m.from_pydata([(-.2,0,0),(.2,0,0),(-.2,0,1),(.2,0,1),(-.2,0,2),(.2,0,2)],[],[(0,1,3,2),(2,3,5,4)]);m.update()
o=bpy.data.objects.new('Coifa Câmbio',m);bpy.context.collection.objects.link(o)
a=o.vertex_groups.new(name='Base Cambio');a.add([0,1],1,'REPLACE');a.add([2,3],.5,'REPLACE')
b=o.vertex_groups.new(name='Cabeca Cambio');b.add([4,5],1,'REPLACE');b.add([2,3],.5,'REPLACE')
uv=m.uv_layers.new()
for i,loop in enumerate(m.loops):uv.data[i].uv=(m.vertices[loop.vertex_index].co.x+.2,m.vertices[loop.vertex_index].co.z/2)
marker=bpy.data.objects.new('PIVOT__Cabeca Cambio',None);bpy.context.collection.objects.link(marker);marker.location=(0,0,1)
bpy.ops.mesh.primitive_plane_add(location=(1,2,3));bpy.context.object.name='LUZ__Painel';bpy.context.object['omsi_variable']='throttle'
bpy.ops.wm.save_as_mainfile(filepath=sys.argv[-1],compress=True)
