import math,struct,tempfile,unittest
from pathlib import Path
from vendor import meshio
from obj_export import export_obj,export_project_obj
from o3d_binary import scan

def fixture(version=7,long=False):
 m=meshio.Mesh()
 # O3D axes X,Y-up,Z-forward. The pivot must NOT move these positions.
 m.vertices=[meshio.Vertex(meshio.Vector3(*v),meshio.Vector3(0,1,0),meshio.Vector2(*uv)) for v,uv in [((2,4,3),(0.1,0.2)),((4,4,3),(0.8,0.2)),((2,4,6),(0.1,0.9))]]
 m.triangles=[meshio.Triangle((2,1,0),0)]
 m.materials=[meshio.Material(texture='paint.png')]
 m.matrix=((1,0,0,0),(0,1,0,0),(0,0,1,0),(100,200,300,1))
 return meshio.dump(m,meshio.MeshFormatSpec(version,longIndexes=long))

class ObjTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.source=self.root/'source';self.source.mkdir();self.mesh=self.source/'part.o3d';self.mesh.write_bytes(fixture());self.tex=self.root/'textures';self.tex.mkdir();(self.tex/'paint.png').write_bytes(b'texture')
 def tearDown(self):self.tmp.cleanup()
 def test_geometry_uv_winding_material_and_pivot(self):
  out=self.root/'out';result=export_obj([(self.mesh,'part.obj')],out,[self.tex]);lines=(out/'part.obj').read_text().splitlines()
  self.assertIn('v 2 3 4',lines);self.assertFalse(any(line.startswith('v 102 ') for line in lines));self.assertIn('vn 0 0 1',lines);self.assertIn('f 1/1/1 2/2/2 3/3/3',lines)
  uv=[list(map(float,l.split()[1:])) for l in lines if l.startswith('vt ')];self.assertAlmostEqual(uv[0][0],.1,6);self.assertAlmostEqual(uv[0][1],.8,6)
  mtl=(out/'part.mtl').read_text();self.assertIn('newmtl material_0',mtl);texture=mtl.split('map_Kd ')[1].splitlines()[0];self.assertEqual((out/texture).read_bytes(),b'texture');self.assertEqual(result['warnings'],[])
 def test_v1_and_long_indices(self):
  for ver,long in [(1,False),(3,False),(7,True)]:
   with self.subTest(ver=ver,long=long):
    self.mesh.write_bytes(fixture(ver,long));info=scan(self.mesh.read_bytes(),geometry=True);self.assertEqual(info['triangle_data'],[(2,1,0,0)])
    export_obj([(self.mesh,'part.obj')],self.root/f'out_{ver}',[self.tex])
 def test_missing_texture_report_and_backup(self):
  out=self.root/'out';out.mkdir();(out/'part.obj').write_text('old');(out/'other.txt').write_text('keep');result=export_obj([(self.mesh,'part.obj')],out)
  self.assertIn('paint.png',result['warnings'][0]);self.assertTrue(list(out.glob('backup_exportacao_*.zip')));self.assertEqual((out/'other.txt').read_text(),'keep');self.assertNotIn('map_Kd',(out/'part.mtl').read_text())
 def test_corrupt_geometry_no_partial_output(self):
  for bad in [fixture()[:-2],fixture()[:4]+struct.pack('<I',123)+fixture()[8:],fixture()[:13]+struct.pack('<f',math.nan)+fixture()[17:]]:
   self.mesh.write_bytes(bad)
   with self.assertRaises(ValueError):export_obj([(self.mesh,'part.obj')],self.root/'out')
   self.assertFalse((self.root/'out/part.obj').exists())
 def test_selected_all_and_path_collision(self):
  project=self.root/'project';(project/'model/Painel').mkdir(parents=True);(project/'texture').mkdir();(project/'texture/paint.png').write_bytes(b'texture')
  for name in ('a','b'):(project/'model/Painel'/f'{name}.o3d').write_bytes(fixture())
  data={'parts':[{'id':name,'file':f'Painel/{name}.o3d'} for name in ('a','b')]};out=self.root/'out'
  export_project_obj(project,data,out,['a']);self.assertTrue((out/'Painel/a.obj').exists());self.assertFalse((out/'Painel/b.obj').exists());export_project_obj(project,data,out);self.assertTrue((out/'Painel/b.obj').exists())
  mtl=(out/'Painel/a.mtl').read_text();self.assertIn('map_Kd ../texturas_obj/',mtl)
  with self.assertRaises(ValueError):export_obj([(self.mesh,'a.obj'),(self.mesh,'A.obj')],out)
  with self.assertRaises(ValueError):export_project_obj(project,data,project/'out')
  with self.assertRaises(ValueError):export_obj([(self.mesh,'../escape.obj')],out)
 def test_duplicate_and_bad_indices_rejected(self):
  data=fixture();info=scan(data);self.assertEqual(info['vertices'],3)
  with self.assertRaises(ValueError):scan(data+b'\x17'+struct.pack('<I',0),geometry=True)
  start=8+5+3*32+5;bad=data[:start]+struct.pack('<H',22)+data[start+2:]
  with self.assertRaises(ValueError):scan(bad,geometry=True)

if __name__=='__main__':unittest.main()
