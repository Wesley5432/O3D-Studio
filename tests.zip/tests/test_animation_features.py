import copy,json,math,subprocess,tempfile,unittest
from pathlib import Path
from animation_math import identity,rotation,translation,multiply,inverse,transform,piece_matrix,matrices,deformed_vertices,mesh_origin
from project import new_project,render_cfg,validate_project,recipe
from asset_paths import source_mesh_name
from model_lights import render_lights,validate_lights
from o3d_binary import scan
from engine import blender_path

class AnimationTests(unittest.TestCase):
 def test_original_names_and_collision_only_suffix(self):
  used=set();self.assertEqual(source_mesh_name('Volante Mercedes.001',used),'Volante Mercedes.001.o3d');self.assertEqual(source_mesh_name('Coifa Câmbio',used),'Coifa Câmbio.o3d');self.assertEqual(source_mesh_name('coifa câmbio',used),'coifa câmbio_2.o3d');self.assertEqual(source_mesh_name('CON',used),'_CON.o3d');self.assertEqual(source_mesh_name('Porta:1/2',used),'Porta_1_2.o3d')
 def test_pivot_rotation_translation_and_inverse(self):
  p={'pivot':[0,0,1],'animations':[{'type':'rot','variable':'test','factor':90,'origin_rotation':[0,0,0]}]}
  m=piece_matrix(p,{}, {'test':1});v=transform(m,[0,0,2]);self.assertAlmostEqual(v[1],1);self.assertAlmostEqual(v[2],1);self.assertEqual(transform(m,[0,0,1]),[0,0,1])
  for a,b in zip(transform(inverse(m),v),[0,0,2]):self.assertAlmostEqual(a,b)
  p['animations'][0]['type']='trans';p['animations'][0]['factor']=2;self.assertEqual(transform(piece_matrix(p,{}, {'test':.5}),[0,0,2]),[1,0,2])
 def test_origin_matrix_not_baked_into_static_geometry_and_axis(self):
  raw=[1,0,0,0,0,1,0,0,0,0,1,0,2,4,3,1]
  self.assertEqual(transform(mesh_origin(raw),[0,0,0]),[2,3,4])
  p={'pivot':None,'animations':[{'type':'rot','variable':'test','factor':90,'origin_rotation':[0,0,0]}]}
  self.assertEqual(transform(piece_matrix(p,{'matrix':raw},{'test':0}),[5,6,7]),[5,6,7])
 def test_parent_motion_and_cycles(self):
  project=new_project({'meshes':[{'object':x,'file':x+'.o3d'} for x in ('arm','blade')]});a,b=project['parts'];a['pivot']=[0,0,0];a['animations']=recipe('wiper','brake',90);b['parent']=a['id'];infos={p['id']:{} for p in project['parts']}
  result=matrices(project,infos,{'brake':1});self.assertAlmostEqual(transform(result[b['id']],[0,0,1])[1],1)
  a['parent']=b['id']
  with self.assertRaises(ValueError):matrices(project,infos,{})
 def test_smoothskin_base_fixed_top_follows_controller_and_cfg_indices(self):
  project=new_project({'meshes':[{'object':'Coifa','file':'Coifa.o3d','bones':['Base','Cabeca']},{'object':'Base','file':'Base.o3d'},{'object':'Cabeca','file':'Cabeca.o3d'}]});skin,base,head=project['parts'];head['pivot']=[0,0,1];head['animations']=recipe('lever','brake',90)
  cfg=render_cfg(project);self.assertLess(cfg.index('[mesh]\nBase.o3d'),cfg.index('[mesh]\nCoifa.o3d'));self.assertIn('[setbone]\nBase\n0',cfg);self.assertIn('[setbone]\nCabeca\n1',cfg)
  info={'vertex_data':[(0,0,0,0,1,0,0,0),(0,1,0,0,1,0,0,0),(0,2,0,0,1,0,0,0)],'bone_data':[{'name':'Base','weights':[(0,1),(1,.5)]},{'name':'Cabeca','weights':[(1,.5),(2,1)]}]}
  transforms=matrices(project,{p['id']:{} for p in project['parts']},{'brake':1});vertices=deformed_vertices(skin,info,transforms)
  self.assertEqual(vertices[0],[0,0,0]);self.assertAlmostEqual(vertices[2][1],1);self.assertAlmostEqual(vertices[2][2],1)
  skin['skin_bindings']['Cabeca']=skin['id']
  with self.assertRaises(ValueError):render_cfg(project)
 def test_light_coordinates_and_variable_validation(self):
  light={'name':'Painel','type':'interiorlight','variable':'throttle','xyz':[1,-.746963,2],'rgb':[255,200,100],'range':3}
  validate_lights([light],{});self.assertIn('[interiorlight]\nthrottle\n3\n255\n200\n100\n1\n-0.746963\n2','\n'.join(render_lights([light])))
  light['variable']='unknown'
  with self.assertRaises(ValueError):validate_lights([light],{})
  light.update(type='spotlight',direction=[0,0,0],inner=20,outer=40)
  with self.assertRaises(ValueError):validate_lights([light],{})
 def test_reference_cfg_preview_uses_actual_sources_origins_and_parent(self):
  import test_template
  from assembly_preview import preview_project
  case=test_template.TemplateTests();case.setUp()
  try:
   case.p['mapping']['mesh_0000']['variables']={'brake':'throttle'}
   project=preview_project(case.t,case.p,{})
   p=project['parts'][0];self.assertEqual(p['preview_source'],str(case.base/'Model/door.o3d'));self.assertEqual(p['animations'][0]['variable'],'throttle');self.assertEqual(p['animations'][0]['origin_steps'],[('origin_from_mesh',None),('origin_rot_y',90.0)])
  finally:case.tearDown()
 @unittest.skipUnless(blender_path(),'Blender externo não instalado')
 def test_blender_names_markers_weights_and_obj_import(self):
  from engine import run,blender_path
  from obj_export import export_project_obj
  with tempfile.TemporaryDirectory() as temp:
   root=Path(temp);script=root/'fixture.py';source=root/'bus.blend'
   script.write_text('''import bpy,sys
bpy.ops.wm.read_factory_settings(use_empty=True)
for name,z in [('Base Cambio',0),('Cabeca Cambio',2)]:
 bpy.ops.mesh.primitive_cube_add(size=.1,location=(0,0,z));bpy.context.object.name=name
m=bpy.data.meshes.new('coifa');m.from_pydata([(-.2,0,0),(.2,0,0),(-.2,0,1),(.2,0,1),(-.2,0,2),(.2,0,2)],[],[(0,1,3,2),(2,3,5,4)]);m.update()
o=bpy.data.objects.new('Coifa Câmbio',m);bpy.context.collection.objects.link(o)
a=o.vertex_groups.new(name='Base Cambio');a.add([0,1],1,'REPLACE');a.add([2,3],.5,'REPLACE')
b=o.vertex_groups.new(name='Cabeca Cambio');b.add([4,5],1,'REPLACE');b.add([2,3],.5,'REPLACE')
uv=m.uv_layers.new()
for i,loop in enumerate(m.loops):uv.data[i].uv=(m.vertices[loop.vertex_index].co.x+.2,m.vertices[loop.vertex_index].co.z/2)
marker=bpy.data.objects.new('PIVOT__Cabeca Cambio',None);bpy.context.collection.objects.link(marker);marker.location=(0,0,1)
bpy.ops.mesh.primitive_plane_add(location=(1,2,3));bpy.context.object.name='LUZ__Painel';bpy.context.object['omsi_variable']='throttle'
bpy.ops.wm.save_as_mainfile(filepath=sys.argv[-1])
''',encoding='utf8')
   result=subprocess.run([blender_path(),'-b','--factory-startup','--python-exit-code','1','--python',str(script),'--',str(source)],capture_output=True,text=True,timeout=120);self.assertEqual(result.returncode,0,result.stdout+result.stderr)
   out=run(source,root/'converted',preserve_skin=True);report=json.loads((out/'report.json').read_text());self.assertEqual({m['file'] for m in report['meshes']},{'Base Cambio.o3d','Cabeca Cambio.o3d','Coifa Câmbio.o3d'});self.assertEqual(len(report['markers']),2);self.assertEqual(next(m for m in report['markers'] if m['kind']=='light')['xyz'],[1.,2.,3.])
   info=scan((out/'model/Coifa Câmbio.o3d').read_bytes(),geometry=True);self.assertEqual(info['bone_names'],['Base Cambio','Cabeca Cambio']);totals=[0.]*info['vertices']
   for bone in info['bone_data']:
    for i,w in bone['weights']:totals[i]+=w
   self.assertTrue(all(abs(x-1)<1e-6 for x in totals));project=json.loads((out/'project.json').read_text());cfg=render_cfg(project);self.assertIn('[smoothskin]',cfg);self.assertIn('Cabeca Cambio',cfg)
   export=export_project_obj(out,project,root/'obj');self.assertEqual(len(export['files']),3);self.assertTrue(any('ossos/pesos' in w for w in export['warnings']))
   verify=root/'verify.py';verify.write_text('''import bpy,json,sys
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.wm.obj_import(filepath=sys.argv[-2],forward_axis='Y',up_axis='Z')
o=next(o for o in bpy.context.scene.objects if o.type=='MESH')
with open(sys.argv[-1],'w') as f:json.dump({'v':[list(v.co) for v in o.data.vertices],'uv':[list(v.uv) for v in o.data.uv_layers.active.data],'faces':len(o.data.polygons)},f)
''')
   result=subprocess.run([blender_path(),'-b','--factory-startup','--python-exit-code','1','--python',str(verify),'--',str(root/'obj/Coifa Câmbio.obj'),str(root/'verified.json')],capture_output=True,text=True,timeout=120);self.assertEqual(result.returncode,0,result.stdout+result.stderr)
   loaded=json.loads((root/'verified.json').read_text());self.assertEqual(loaded['faces'],4);self.assertAlmostEqual(max(v[2] for v in loaded['v']),2);self.assertAlmostEqual(max(v[0] for v in loaded['v']),.2,6);self.assertAlmostEqual(max(uv[1] for uv in loaded['uv']),1)

if __name__=='__main__':unittest.main()
