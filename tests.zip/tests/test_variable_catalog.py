import unittest
from variable_catalog import cfg_usages,build_catalog,script_usages
from project import variable_ok

class CatalogTests(unittest.TestCase):
 def test_volante_context_and_exact_lines(self):
  cfg='[mesh]\nPainel\\Volante.o3d\n[mouseevent]\ncp_whe_pos\n[visible]\ncp_lenkrad_visible\n1\n[newanim]\norigin_from_mesh\norigin_rot_y\n90\nanim_rot\nAxle_Steering_0_L\n1200\n'
  rows=cfg_usages(cfg,'model.cfg','front.bus');self.assertEqual(len(rows),3)
  animation=next(r for r in rows if r['role']=='Rotação');self.assertEqual(animation['mesh'],'Painel\\Volante.o3d');self.assertEqual(animation['line'],13);self.assertIn('1200',animation['description']);self.assertIn('origin_rot_y = 90',animation['description']);self.assertEqual(animation['section'],'front.bus')
 def test_multiple_usages_types_and_no_invented_meaning(self):
  cfg='[texttexture]\nline\nFonte\n[mesh]\na.o3d\n[visible]\nstate\n1\n[mesh]\nb.o3d\n[matl_change]\npaint.png\n0\nstate\n'
  rows=build_catalog([('cfg',cfg,'')],{'variables':['state','unknown'],'string_variables':['line']})
  state=next(r for r in rows if r['name']=='state');self.assertEqual(len(state['usages']),2);self.assertEqual(state['roles'],['Material','Visibilidade'])
  unknown=next(r for r in rows if r['name']=='unknown');self.assertIn('finalidade não deduzida',unknown['summary']);self.assertEqual(unknown['usages'],[])
  self.assertEqual(next(r for r in rows if r['name']=='line')['kind'],'strings')
 def test_events_drag_off_and_script_read_write(self):
  script="{trigger:button_drag}\n(L.L.position) 1 + (S.L.position)\n{end}\n' (S.L.comment_only)\n{trigger:button_off}\n{end}"
  rows=build_catalog([('cfg','[mesh]\nx.o3d\n[mouseevent]\nbutton\n','')],script_sources=[('buttons.osc',script)])
  event=next(r for r in rows if r['name']=='button');self.assertEqual(len(event['usages']),3);self.assertEqual(event['kind'],'events');self.assertFalse(any(r['name']=='comment_only' for r in rows))
  position=next(r for r in rows if r['name']=='position');self.assertEqual(position['roles'],['Escrita no script','Leitura no script']);self.assertEqual(position['usages'][0]['line'],2)
 def test_disabled_indented_blocks_constants_and_ids_not_variables(self):
  cfg=' [visible]\nignored\n1\n-<DISABLED>-\n[visible]\ndisabled\n1\n-<ENABLED>-\n[mesh]\na.o3d\n[mesh_ident]\nidentity\n[animparent]\nparent\n[interiorlight]\n0.5\n2\n255\n255\n255\n0\n1\n2\n[visible]\nactive\n1\n'
  self.assertEqual([r['name'] for r in cfg_usages(cfg)],['active'])
 def test_lights_uv_texture_and_articulation(self):
  cfg='[light_enh_2]\n'+'\n'.join(['0']*17+['lights_stand','1'])+'\n[matl_freetex]\nbase.png\nimage_name\n[texcoordtransY]\nscroll_y\n'
  rows=cfg_usages(cfg);self.assertEqual({r['name'] for r in rows},{'lights_stand','image_name','scroll_y'});self.assertTrue(variable_ok('articulation_1_alpha',None));self.assertFalse(variable_ok('articulation_fake_alpha',None))
 def test_disabled_animation_does_not_leak_into_previous_block(self):
  text='[newanim]\nanim_rot\nactive\n90\n-<DISABLED>-\n[newanim]\nanim_rot\ndisabled\n90\n-<ENABLED>-\n'
  self.assertEqual([u['name'] for u in cfg_usages(text)],['active'])

if __name__=='__main__':unittest.main()
