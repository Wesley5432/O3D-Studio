import unittest
from skin_cfg import bindings,patch_skin,validate_bindings

class SkinCfgTests(unittest.TestCase):
 def fixture(self):
  pieces=[{'id':'p0','mesh':'unused.o3d','block':'[mesh]\nunused.o3d\n'},{'id':'p1','mesh':'head.o3d','block':'[mesh]\nhead.o3d\n'},{'id':'p2','mesh':'skin.o3d','block':'[mesh]\nskin.o3d\n[smoothskin]\n[setbone]\nTop\n1\n'}]
  return {'pieces':pieces},{'mapping':{'p0':{'mode':'remove'},'p1':{'mode':'keep'},'p2':{'mode':'keep'}}}
 def test_reindex_after_removing_unrelated_mesh(self):
  t,p=self.fixture();block=patch_skin(t['pieces'][2]['block'],t,p,t['pieces'][2],{});self.assertIn('[setbone]\nTop\n0',block)
 def test_removed_controller_is_rejected(self):
  t,p=self.fixture();p['mapping']['p1']['mode']='remove'
  with self.assertRaises(ValueError):validate_bindings(t,p,{})
 def test_replacement_maps_new_group_to_controller(self):
  t,p=self.fixture();p['mapping']['p2']={'mode':'replace','target':'new.o3d','bones':{'Cabeca':'p1'}};targets={'new.o3d':{'bones_actual':['Cabeca']}}
  block=patch_skin('[mesh]\nnew.o3d\n[smoothskin]\n[setbone]\nTop\n1\n[matl]\npaint.png\n0\n',t,p,t['pieces'][2],targets);self.assertIn('[setbone]\nCabeca\n0',block);self.assertNotIn('\nTop\n',block);self.assertEqual(block.count('[smoothskin]'),1);self.assertIn('[matl]\npaint.png\n0',block)
 def test_missing_weights_and_controller_cycle_rejected(self):
  t,p=self.fixture();p['mapping']['p2']={'mode':'replace','target':'new.o3d'}
  with self.assertRaises(ValueError):validate_bindings(t,p,{'new.o3d':{'bones_actual':[]}})
  p['mapping']['p2']={'mode':'keep'};t['pieces'][1]['block']+='[setbone]\nCycle\n2\n'
  with self.assertRaises(ValueError):validate_bindings(t,p,{})

if __name__=='__main__':unittest.main()
