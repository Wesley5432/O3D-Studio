"""Construct the main Tk screens on a machine with a graphical session."""
import sys,tkinter as tk
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from studio import Studio
from editor import PieceEditor
from articulated_ui import ArticulatedEditor
from catalog_ui import show_catalog
from animation_preview import open_preview
from model_lights import light_editor

root=tk.Tk();root.withdraw();errors=[]
root.report_callback_exception=lambda *args:errors.append(args[1])
studio=Studio(root);editor=PieceEditor(root,Path(__file__).resolve().parents[1]/'examples/Deformacao_Demo');root.update()
skin=next(p for p in editor.project['parts'] if p['name']=='Coifa Câmbio');editor.tree.selection_set(skin['id']);root.update()
preview=open_preview(root,editor.folder,editor.project,skin['id']);preview.value.set(1);preview.draw();root.update()
if preview.status.get().startswith('Prévia:'):errors.append(RuntimeError(preview.status.get()))
show_catalog(root,project=editor.project);ArticulatedEditor(root);light_editor(editor);root.update();preview.close();root.destroy()
if errors:raise RuntimeError('\n'.join(map(str,errors)))
print('Tk UI smoke: telas, seleção e prévia construídas sem erro de callback.')
