import copy,json,tempfile,unittest
from pathlib import Path
from articulated import load_chain,new_articulated_plan,export_articulated,check_articulated
from vehicle_template import load_template,new_plan,build,txt
from variable_catalog import bus_sources
from test_template import mesh

def fixture(root):
 base=root/'base';(base/'Model').mkdir(parents=True);(base/'Texture').mkdir();(base/'Script').mkdir()
 (base/'Script/main.osc').write_text('{init}\n{end}\n{trigger:door}\n{end}\n');(base/'Script/vars.txt').write_text('door_pos\n')
 (base/'front.bus').write_text('[friendlyname]\nMaker\nArticulado\nVariant\n[model]\nModel\\front.cfg\n[script]\n1\nScript\\main.osc\n[varnamelist]\n1\nScript\\vars.txt\n[mass]\n12\n[coupling_back]\n0\n-4.331\n0.315\n[couple_back]\nrear.BUS\nfalse\n')
 (base/'rear.bus').write_text('[model]\nModel\\rear.cfg\n[scriptshare]\n[coupling_front]\n0\n4.169\n0.315\n[coupling_front_character]\n1\n0\n[mass]\n7\n')
 (base/'Model/piece.o3d').write_bytes(mesh('paint.png'));(base/'Texture/paint.png').write_bytes(b'paint')
 for name in ('front','rear'):(base/'Model'/f'{name}.cfg').write_text('[mesh]\npiece.o3d\n[mesh_ident]\nbody\n[newanim]\norigin_from_mesh\nanim_rot\narticulation_1_alpha\n0.5\n[matl]\npaint.png\n0\n')
 (base/'passengers.cfg').write_text('[linkToNextVeh]\n3\n[linkToPrevVeh]\n1\n');return base

class ArticulatedTests(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.base=fixture(self.root)
 def tearDown(self):self.tmp.cleanup()
 def test_load_shared_profiles_and_catalog(self):
  chain=load_chain(self.base/'front.bus');self.assertEqual(len(chain['sections']),2);self.assertTrue(chain['sections'][1]['scriptshare']);self.assertEqual(chain['sections'][1]['profile_bus'],str(self.base/'front.bus'))
  t=load_template(self.base/'rear.bus',profile_bus=self.base/'front.bus');self.assertIn('door_pos',t['profile']['variables'])
  cfgs,scripts,warnings=bus_sources(self.base/'front.bus');self.assertEqual(len(cfgs),2);self.assertEqual(len(scripts),1);self.assertEqual(warnings,[])
 def test_export_preserves_rear_physics_scripts_and_updates_only_points(self):
  plan=new_articulated_plan(self.base/'front.bus');plan['points']={'front.bus':{'back':[0,-5,.4]},'rear.bus':{'front':[0,4,.4]}}
  out=export_articulated(plan,self.root/'out');base=out/'Vehicles/Meu_articulado';self.assertEqual(len(load_chain(base/'front.bus')['sections']),2)
  rear=txt(base/'rear.bus');self.assertIn('[scriptshare]',rear);self.assertIn('[mass]\n7',rear);self.assertIn('[coupling_front]\n0\n4\n0.4',rear);self.assertEqual((base/'Model/rear.cfg').read_bytes(),(self.base/'Model/rear.cfg').read_bytes());self.assertEqual((base/'passengers.cfg').read_bytes(),(self.base/'passengers.cfg').read_bytes());self.assertIn('-4.331',txt(self.base/'front.bus'))
 def test_two_section_replacements_keep_meshes_and_textures_separate(self):
  plan=new_articulated_plan(self.base/'front.bus')
  for i,name in enumerate(('front','rear')):
   project=self.root/name;(project/'model').mkdir(parents=True);(project/'texture').mkdir();(project/'model/new.o3d').write_bytes(mesh('new.png'));(project/'texture/new.png').write_bytes(name.encode());(project/'project.json').write_text(json.dumps({'parts':[{'file':'new.o3d'}]}))
   t=load_template(self.base/f'{name}.bus',profile_bus=self.base/'front.bus');p=new_plan(t,project);p['mapping']={'mesh_0000':{'mode':'replace','target':'new.o3d','materials':{'paint.png|0':0},'confirmed':True}};plan['section_plans'][f'{name}.bus']=p
  base=export_articulated(plan,self.root/'out')/'Vehicles/Meu_articulado'
  for i,name in enumerate(('front','rear')):
   cfg=txt(base/f'Model/{name}.cfg');self.assertIn(f'Convertidos_S0{i}\\new.o3d',cfg);self.assertTrue((base/f'Model/Convertidos_S0{i}/new.o3d').exists());self.assertEqual(next((base/'Texture').glob(f'CV_S0{i}_*')).read_bytes(),name.encode());self.assertIn('articulation_1_alpha',cfg)
  self.assertEqual(plan['section_plans']['rear.bus'].get('namespace'),None)
 def test_main_assembly_no_longer_deletes_trailer(self):
  t=load_template(self.base/'front.bus');p=new_plan(t,'');p['mapping']={'mesh_0000':{'mode':'keep'}}
  base=build(t,p,self.root/'out')/'Vehicles/Meu_veiculo';self.assertTrue((base/'rear.bus').exists());self.assertEqual(len(load_chain(base/'front.bus')['sections']),2)
 def test_missing_rear_cycle_escape_and_bad_points_rejected(self):
  front=self.base/'front.bus';original=front.read_text()
  for ref in ('missing.bus','front.bus','..\\elsewhere.bus'):
   front.write_text(original.replace('rear.BUS',ref))
   with self.assertRaises(ValueError):load_chain(front)
  front.write_text(original);plan=new_articulated_plan(front);plan['points']={'rear.bus':{'front':[0,float('nan'),1]}}
  with self.assertRaises(ValueError):export_articulated(plan,self.root/'out')
  self.assertFalse((self.root/'out/Vehicles').exists())
 def test_stale_base_and_wrong_section_plan_rejected(self):
  plan=new_articulated_plan(self.base/'front.bus');cfg=self.base/'Model/rear.cfg';cfg.write_text(cfg.read_text()+'\n')
  with self.assertRaises(ValueError):check_articulated(plan)
  plan=new_articulated_plan(self.base/'front.bus');t=load_template(self.base/'front.bus');p=new_plan(t,'');p['mapping']={'mesh_0000':{'mode':'keep'}};plan['section_plans']['rear.bus']=p
  with self.assertRaises(ValueError):check_articulated(plan)
 def test_source_output_and_shared_cfg_conflict(self):
  plan=new_articulated_plan(self.base/'front.bus')
  with self.assertRaises(ValueError):export_articulated(plan,self.base/'out')
  rear=self.base/'rear.bus';rear.write_text(rear.read_text().replace('rear.cfg','front.cfg'));plan=new_articulated_plan(self.base/'front.bus');t=load_template(self.base/'front.bus');p=new_plan(t,'');p['mapping']={'mesh_0000':{'mode':'keep'}};plan['section_plans']['front.bus']=p
  with self.assertRaisesRegex(ValueError,'mesmo CFG'):check_articulated(plan)

if __name__=='__main__':unittest.main()
